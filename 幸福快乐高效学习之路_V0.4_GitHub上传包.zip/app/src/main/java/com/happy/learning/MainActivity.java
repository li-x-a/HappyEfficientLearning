package com.happy.learning;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import org.json.*;


class LearningEngine {
    static class Plan {
        String goal, currentLevel, deadline, dailyMinutes;
        java.util.ArrayList<Stage> stages = new java.util.ArrayList<>();
    }
    static class Stage {
        String name, purpose, standard;
        java.util.ArrayList<String> steps = new java.util.ArrayList<>();
    }

    static Plan build(String goal, String level, String deadline, String minutes) {
        Plan p = new Plan();
        p.goal = goal; p.currentLevel = level; p.deadline = deadline; p.dailyMinutes = minutes;
        String g = goal.toLowerCase();

        if (g.contains("python") || goal.contains("编程")) {
            add(p,"阶段1：基础环境","能独立运行并理解最基本的代码",
                    "连续3次正确运行并解释自己的代码",
                    "运行第一行代码","变量与数据类型","输入与输出","3道基础小题");
            add(p,"阶段2：控制流程","能让程序按条件和重复规则工作",
                    "独立完成5道条件/循环题，正确率≥80%",
                    "if 判断","for 循环","while 循环","综合练习");
            add(p,"阶段3：函数与数据","能把代码组织成可复用的小模块",
                    "独立写出3个函数并正确处理参数",
                    "函数","列表与字典","字符串处理","综合练习");
            add(p,"阶段4：独立项目","能从需求到结果独立完成小程序",
                    "限定时间内独立完成一个小项目并通过检查",
                    "选题","拆需求","编码","测试与修改");
        } else if (goal.contains("英语") || g.contains("english")) {
            add(p,"阶段1：高频词与句子","建立新闻阅读所需的基础词汇和句型",
                    "阶段测试中高频词/基础句理解率≥80%",
                    "每日10～15个高频词","5个短句精读","回忆测试","错词回收");
            add(p,"阶段2：短新闻","能抓住简单新闻的主旨和关键信息",
                    "连续3篇短新闻主旨判断正确率≥80%",
                    "标题理解","首段精读","关键词定位","主旨复述");
            add(p,"阶段3：真实新闻","逐步适应正常新闻表达",
                    "10分钟内读完短新闻并写出3句摘要",
                    "段落结构","连接词","长句拆解","摘要");
            add(p,"阶段4：独立阅读","能稳定阅读英文新闻并提取关键信息",
                    "独立阅读一篇目标难度新闻并达到80%理解标准",
                    "限时阅读","信息提取","摘要","阶段测试");
        } else if (goal.contains("数学") || g.contains("math")) {
            add(p,"阶段1：概念","能准确理解并解释核心概念",
                    "随机抽查10个概念，正确率≥80%",
                    "概念卡","例题","反例","口述解释");
            add(p,"阶段2：基础题","能稳定解决基础题型",
                    "连续10题正确率≥80%",
                    "题型识别","基础练习","错题分析","再测");
            add(p,"阶段3：变式题","能处理不同问法和组合条件",
                    "5道变式题正确率≥80%",
                    "变式1","变式2","多步骤题","限时练习");
            add(p,"阶段4：综合应用","能独立解决陌生综合问题",
                    "阶段测试达到预设标准",
                    "审题","建模","计算","检查");
        } else {
            add(p,"阶段1：定义结果","把“学会”变成可检查的结果",
                    "能明确说出并完成一个可验证成果",
                    "定义成果","最小动作","第一次尝试","记录问题");
            add(p,"阶段2：基础动作","形成最基本的正确操作",
                    "连续3次独立完成基础动作",
                    "示范","模仿","独立做","复盘");
            add(p,"阶段3：变式练习","面对变化仍能完成",
                    "3种不同情境下都达到标准",
                    "变式1","变式2","变式3","错误修正");
            add(p,"阶段4：独立应用","不依赖提示完成完整任务",
                    "独立完成一次完整成果并通过测试",
                    "准备","执行","检查","测试");
        }
        return p;
    }

    static void add(Plan p,String name,String purpose,String standard,String... steps) {
        Stage st=new Stage(); st.name=name; st.purpose=purpose; st.standard=standard;
        for(String x:steps) st.steps.add(x);
        p.stages.add(st);
    }
}

public class MainActivity extends Activity {
    final int BLUE=Color.rgb(37,99,235), GREEN=Color.rgb(22,163,74), RED=Color.rgb(220,38,38);
    final int TEXT=Color.rgb(17,24,39), MUTED=Color.rgb(100,116,139), BG=Color.rgb(248,250,252), BORDER=Color.rgb(226,232,240);
    LinearLayout root, content;
    int tab=0;
    SimpleDateFormat day=new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA);
    SimpleDateFormat displayDay=new SimpleDateFormat("M月d日 E",Locale.CHINA);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},88);
        normalize();
        home();
    }

    void normalize(){
        String today=day.format(new Date());
        JSONArray a=Store.get(this,"tasks");
        boolean changed=false;
        for(int i=0;i<a.length();i++){
            try{
                JSONObject o=a.getJSONObject(i);
                if(!o.optString("date").equals(today) && o.optBoolean("locked") && "PENDING".equals(o.optString("status"))){
                    o.put("status","RETURN"); changed=true;
                }
            }catch(Exception ignored){}
        }
        if(changed) Store.put(this,"tasks",a);
    }

    TextView text(String s,float size){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(TEXT);
        v.setPadding(0,5,0,5); return v;
    }
    TextView title(String s){
        TextView v=text(s,23); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;
    }
    Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(14); b.setAllCaps(false); return b;
    }
    LinearLayout card(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(17,13,17,13);
        android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();
        g.setColor(Color.WHITE); g.setCornerRadius(22); g.setStroke(1,BORDER); c.setBackground(g);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,7,0,7); c.setLayoutParams(lp);
        return c;
    }
    void base(String heading){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        root.setPadding(20,16,20,8);
        setContentView(root);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title(heading),new LinearLayout.LayoutParams(0,-2,1));
        root.addView(bar);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        NavigationBar nav=new NavigationBar(this);
        LinearLayout navBox=new LinearLayout(this); navBox.setGravity(Gravity.CENTER);
        String[] labels={"首页","计划","学习","统计","我的"};
        for(int i=0;i<labels.length;i++){
            final int x=i; Button b=button(labels[i]); b.setOnClickListener(v->{tab=x; render();});
            navBox.addView(b,new LinearLayout.LayoutParams(0,50,1));
        }
        root.addView(navBox);
    }
    void render(){ if(tab==0)home(); else if(tab==1)plans(); else if(tab==2)learning(); else if(tab==3)stats(); else mine(); }

    JSONArray tasks(){ return Store.get(this,"tasks"); }
    JSONArray goals(){ return Store.get(this,"goals"); }
    JSONArray tests(){ return Store.get(this,"tests"); }

    void home(){
        base("幸福快乐高效学习之路");
        content.addView(text("今天也要更进一步",16));
        content.addView(text(displayDay.format(new Date()),13));

        JSONArray a=tasks(); String today=day.format(new Date()); int total=0,done=0,ret=0;
        for(int i=0;i<a.length();i++) try{
            JSONObject o=a.getJSONObject(i);
            if(today.equals(o.optString("date"))){ total++; if("DONE".equals(o.optString("status"))) done++; }
            if("RETURN".equals(o.optString("status"))) ret++;
        }catch(Exception ignored){}

        LinearLayout p=card(); p.addView(text("今日学习进度",14)); TextView pct=text((total==0?0:done*100/total)+"%",34); pct.setTextColor(BLUE); pct.setTypeface(Typeface.DEFAULT,Typeface.BOLD); p.addView(pct);
        p.addView(text(done+" / "+total+" 项已完成",13)); content.addView(p);

        if(ret>0){
            LinearLayout r=card(); TextView rt=text("🔴 回归任务  "+ret+" 项",17); rt.setTextColor(RED); r.addView(rt);
            r.addView(text("未完成不会消失，今天继续回到主线。",13));
            Button b=button("立即回归"); b.setOnClickListener(v->returnDialog()); r.addView(b); content.addView(r);
        }

        content.addView(text("今日任务",18));
        boolean any=false;
        for(int i=0;i<a.length();i++) try{
            JSONObject o=a.getJSONObject(i);
            if(today.equals(o.optString("date")) || "RETURN".equals(o.optString("status"))){
                addTaskCard(o); any=true;
            }
        }catch(Exception ignored){}
        if(!any) content.addView(text("今天没有任务。先安排明天。",14));

        Button add=button("＋ 创建明日任务"); add.setOnClickListener(v->createTask()); content.addView(add);
        Button pbtn=button("查看 / 锁定明日计划"); pbtn.setOnClickListener(v->tomorrow()); content.addView(pbtn);
    }

    void addTaskCard(JSONObject o){
        LinearLayout c=card();
        String status=o.optString("status","PENDING");
        String prefix="DONE".equals(status)?"☑":"RETURN".equals(status)?"🔴":"☐";
        TextView t=text(prefix+"  "+o.optString("title"),16); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); c.addView(t);
        c.addView(text(o.optString("time")+"  ·  "+o.optString("detail"),13));
        if("DONE".equals(status)){ TextView s=text("已完成",13); s.setTextColor(GREEN); c.addView(s); }
        else { Button b=button("执行"); b.setOnClickListener(v->execute(o)); c.addView(b); }
        content.addView(c);
    }

    void createTask(){
        Dialog d=new Dialog(this);
        LinearLayout l=dialogBox("创建明日任务");
        l.addView(text("把动作、数量、标准写具体。",13));
        EditText name=new EditText(this); name.setHint("任务名称"); l.addView(name);
        EditText detail=new EditText(this); detail.setHint("具体动作 + 数量 + 完成标准"); l.addView(detail);
        TimePicker tp=new TimePicker(this); tp.setIs24HourView(true); l.addView(tp);
        Button save=button("保存"); save.setOnClickListener(v->{
            if(name.getText().toString().trim().isEmpty()){toast("请填写任务名称");return;}
            JSONObject o=new JSONObject();
            try{
                o.put("id",Store.id()); o.put("title",name.getText().toString().trim());
                o.put("detail",detail.getText().toString().trim());
                o.put("date",day.format(new Date(System.currentTimeMillis()+86400000L)));
                o.put("time",String.format(Locale.CHINA,"%02d:%02d",tp.getHour(),tp.getMinute()));
                o.put("status","PENDING"); o.put("locked",false); o.put("type","routine");
                JSONArray a=tasks(); a.put(o); Store.put(this,"tasks",a); d.dismiss(); home();
            }catch(Exception ignored){}
        }); l.addView(save);
        Button cancel=button("取消"); cancel.setOnClickListener(v->d.dismiss()); l.addView(cancel);
        d.setContentView(l); d.show();
    }

    void tomorrow(){
        Dialog d=new Dialog(this); LinearLayout l=dialogBox("明日计划");
        String tm=day.format(new Date(System.currentTimeMillis()+86400000L));
        JSONArray a=tasks(); boolean any=false;
        for(int i=0;i<a.length();i++) try{
            JSONObject o=a.getJSONObject(i); if(tm.equals(o.optString("date"))){
                any=true; l.addView(text((o.optBoolean("locked")?"🔒 ":"☐ ")+o.optString("time")+"  "+o.optString("title")+"\n"+o.optString("detail"),14));
            }
        }catch(Exception ignored){}
        if(!any) l.addView(text("还没有明日任务。",14));
        Button lock=button("🔒 锁定明日计划"); lock.setOnClickListener(v->{
            JSONArray x=tasks(); boolean found=false;
            for(int i=0;i<x.length();i++) try{
                JSONObject o=x.getJSONObject(i);
                if(tm.equals(o.optString("date"))){o.put("locked",true); found=true; schedule(o);}
            }catch(Exception ignored){}
            Store.put(this,"tasks",x); d.dismiss(); toast(found?"计划已锁定：标准进入执行阶段。":"没有可锁定任务"); home();
        }); l.addView(lock);
        Button close=button("关闭"); close.setOnClickListener(v->d.dismiss()); l.addView(close);
        d.setContentView(l); d.show();
    }

    void execute(JSONObject task){
        Dialog d=new Dialog(this); LinearLayout l=dialogBox("执行任务");
        l.addView(title(task.optString("title")));
        l.addView(text(task.optString("detail"),14));
        String type=task.optString("type","routine");
        if("breakthrough".equals(type)){
            l.addView(text("🔒 通关标准",16));
            l.addView(text(task.optString("standard","未设置"),14));
            l.addView(text("标准一旦锁定，本次挑战不会因为失败而降低。",13));
        }
        Button done=button("✓ 达到标准 / 完成"); done.setOnClickListener(v->{
            setStatus(task,"DONE"); d.dismiss(); home();
        }); l.addView(done);
        Button fail=button("✕ 未达到标准 / 失败"); fail.setOnClickListener(v->{
            setStatus(task,"RETURN"); d.dismiss(); home();
        }); l.addView(fail);
        Button later=button("稍后处理"); later.setOnClickListener(v->d.dismiss()); l.addView(later);
        d.setContentView(l); d.show();
    }

    void setStatus(JSONObject target,String status){
        JSONArray a=tasks();
        for(int i=0;i<a.length();i++) try{
            JSONObject o=a.getJSONObject(i);
            if(o.optString("id").equals(target.optString("id"))){o.put("status",status);}
        }catch(Exception ignored){}
        Store.put(this,"tasks",a);
    }

    void returnDialog(){
        Dialog d=new Dialog(this); LinearLayout l=dialogBox("🔴 回归任务");
        l.addView(text("标准不降低，任务不消失。重新执行直到达到原标准。",13));
        JSONArray a=tasks();
        for(int i=0;i<a.length();i++) try{
            JSONObject o=a.getJSONObject(i);
            if("RETURN".equals(o.optString("status"))){
                LinearLayout c=card(); c.addView(text(o.optString("title"),16)); c.addView(text(o.optString("detail"),13));
                Button b=button("重新执行"); b.setOnClickListener(v->{d.dismiss();execute(o);}); c.addView(b); l.addView(c);
            }
        }catch(Exception ignored){}
        Button close=button("关闭"); close.setOnClickListener(v->d.dismiss()); l.addView(close);
        d.setContentView(l); d.show();
    }

    void plans(){
        base("计划");
        content.addView(text("把长期目标拆成两种计划",14));
        Button r=button("＋ 新建流程性计划"); r.setOnClickListener(v->newPlan("routine")); content.addView(r);
        Button b=button("＋ 新建突破性计划"); b.setOnClickListener(v->newPlan("breakthrough")); content.addView(b);

        content.addView(text("我的计划",18));
        JSONArray g=goals();
        if(g.length()==0) content.addView(text("还没有计划。先建立一个。",14));
        for(int i=0;i<g.length();i++) try{ addGoal(g.getJSONObject(i)); }catch(Exception ignored){}
    }

    void addGoal(JSONObject g){
        LinearLayout c=card();
        String type="breakthrough".equals(g.optString("type"))?"突破性计划":"流程性计划";
        c.addView(text(("breakthrough".equals(g.optString("type"))?"🔵 ":"🟢 ")+g.optString("name"),17));
        c.addView(text(type+"  ·  "+g.optString("description"),13));
        if("breakthrough".equals(g.optString("type"))){
            c.addView(text("当前关卡："+g.optInt("current",0)+" / "+g.optInt("total",0),13));
            Button v=button("查看关卡 / 挑战"); v.setOnClickListener(x->breakthrough(g)); c.addView(v);
        }else{
            c.addView(text("每日 "+g.optString("daily")+"  ·  下次阶段测试："+g.optString("test"),13));
            Button v=button("记录 / 阶段测试"); v.setOnClickListener(x->routineTest(g)); c.addView(v);
        }
        content.addView(c);
    }

    void newPlan(String type){
        Dialog d=new Dialog(this); LinearLayout l=dialogBox("新建"+("routine".equals(type)?"流程性":"突破性")+"计划");
        EditText name=new EditText(this); name.setHint("目标名称"); l.addView(name);
        EditText desc=new EditText(this); desc.setHint("目标说明"); l.addView(desc);
        if("routine".equals(type)){
            EditText daily=new EditText(this); daily.setHint("每日动作 + 数量，例如：背 15 个"); l.addView(daily);
            EditText test=new EditText(this); test.setHint("阶段测试标准，例如：50 个中至少 45 个正确"); l.addView(test);
            Button save=button("建立计划"); save.setOnClickListener(v->{
                if(name.getText().toString().trim().isEmpty()){toast("请填写目标名称");return;}
                JSONObject g=new JSONObject();
                try{
                    g.put("id",Store.id()); g.put("type","routine"); g.put("name",name.getText().toString());
                    g.put("description",desc.getText().toString()); g.put("daily",daily.getText().toString());
                    g.put("test",test.getText().toString()); g.put("progress",0);
                    JSONArray a=goals(); a.put(g); Store.put(this,"goals",a); d.dismiss(); plans();
                }catch(Exception ignored){}
            }); l.addView(save);
        }else{
            EditText total=new EditText(this); total.setHint("总关卡数，例如：6"); l.addView(total);
            EditText standard=new EditText(this); standard.setHint("第一关通关标准"); l.addView(standard);
            Button save=button("建立并锁定第一关"); save.setOnClickListener(v->{
                if(name.getText().toString().trim().isEmpty()){toast("请填写目标名称");return;}
                JSONObject g=new JSONObject();
                try{
                    int n=Integer.parseInt(total.getText().toString().trim());
                    g.put("id",Store.id()); g.put("type","breakthrough"); g.put("name",name.getText().toString());
                    g.put("description",desc.getText().toString()); g.put("total",Math.max(1,n)); g.put("current",1);
                    g.put("standard",standard.getText().toString()); g.put("standardLocked",true); g.put("passed",false);
                    JSONArray a=goals(); a.put(g); Store.put(this,"goals",a); d.dismiss(); plans();
                }catch(Exception e){toast("总关卡数请输入数字");}
            }); l.addView(save);
        }
        Button cancel=button("取消"); cancel.setOnClickListener(v->d.dismiss()); l.addView(cancel);
        d.setContentView(l); d.show();
    }

    void routineTest(JSONObject g){
        Dialog d=new Dialog(this); LinearLayout l=dialogBox("阶段测试");
        l.addView(text(g.optString("name"),18)); l.addView(text("测试标准：",15)); l.addView(text(g.optString("test","未设置"),14));
        EditText score=new EditText(this); score.setHint("输入本次结果，例如：47/50"); l.addView(score);
        Button pass=button("测试通过"); pass.setOnClickListener(v->{
            recordTest(g,score.getText().toString(),"PASS"); d.dismiss(); toast("阶段测试通过，继续下一阶段。"); plans();
        }); l.addView(pass);
        Button fail=button("测试未通过"); fail.setOnClickListener(v->{
            recordTest(g,score.getText().toString(),"FAIL"); d.dismiss(); toast("测试未通过，继续当前阶段训练。"); plans();
        }); l.addView(fail);
        d.setContentView(l); d.show();
    }

    void recordTest(JSONObject g,String score,String result){
        JSONArray a=tests(); JSONObject t=new JSONObject();
        try{
            t.put("goalId",g.optString("id")); t.put("date",day.format(new Date())); t.put("score",score); t.put("result",result);
            a.put(t); Store.put(this,"tests",a);
        }catch(Exception ignored){}
    }

    void breakthrough(JSONObject g){
        Dialog d=new Dialog(this); LinearLayout l=dialogBox("过关斩将");
        int current=g.optInt("current",1), total=g.optInt("total",1);
        l.addView(text("第 "+current+" / "+total+" 关",24));
        l.addView(text("本关通关标准（已锁定）",16));
        l.addView(text(g.optString("standard","未设置"),15));
        l.addView(text("标准一旦制定，不因失败而降低。",13));
        Button pass=button("🏆 达到标准 · 永久通关"); pass.setOnClickListener(v->{
            try{
                if(current>=total){
                    g.put("passed",true); g.put("current",total);
                    saveGoal(g); createPermanentRecord(g);
                    d.dismiss(); toast("恭喜，目标永久通关！"); plans();
                }else{
                    g.put("current",current+1);
                    g.put("standard","下一关标准：请在下一次创建时锁定");
                    g.put("standardLocked",false); saveGoal(g);
                    d.dismiss(); toast("本关永久通关，进入下一关。"); plans();
                }
            }catch(Exception ignored){}
        }); l.addView(pass);
        Button fail=button("✕ 未达到标准 · 进入回归"); fail.setOnClickListener(v->{
            d.dismiss(); toast("本关标准保持不变，已进入回归训练。");
        }); l.addView(fail);
        Button close=button("关闭"); close.setOnClickListener(v->d.dismiss()); l.addView(close);
        d.setContentView(l); d.show();
    }

    void saveGoal(JSONObject target){
        JSONArray a=goals();
        for(int i=0;i<a.length();i++) try{
            if(a.getJSONObject(i).optString("id").equals(target.optString("id"))){a.put(i,target);break;}
        }catch(Exception ignored){}
        Store.put(this,"goals",a);
    }
    void createPermanentRecord(JSONObject g){
        JSONArray a=Store.get(this,"passed");
        JSONObject p=new JSONObject();
        try{p.put("goalId",g.optString("id"));p.put("name",g.optString("name"));p.put("date",day.format(new Date()));p.put("status","PERMANENT");a.put(p);Store.put(this,"passed",a);}catch(Exception ignored){}
    }

    void learning(){
        base("学习");
        content.addView(text("流程性计划",19));
        JSONArray g=goals();
        for(int i=0;i<g.length();i++) try{if("routine".equals(g.getJSONObject(i).optString("type"))) addGoal(g.getJSONObject(i));}catch(Exception ignored){}
        content.addView(text("突破性计划",19));
        for(int i=0;i<g.length();i++) try{if("breakthrough".equals(g.getJSONObject(i).optString("type"))) addGoal(g.getJSONObject(i));}catch(Exception ignored){}
    }

    void stats(){
        base("统计");
        JSONArray t=tasks(), test=tests(), pass=Store.get(this,"passed");
        int done=0, total=0, ret=0;
        for(int i=0;i<t.length();i++) try{
            total++; String s=t.getJSONObject(i).optString("status");
            if("DONE".equals(s))done++; if("RETURN".equals(s))ret++;
        }catch(Exception ignored){}
        content.addView(stat("任务完成",done+" / "+total));
        content.addView(stat("阶段测试",String.valueOf(test.length())+" 次"));
        content.addView(stat("永久通关",String.valueOf(pass.length())+" 个"));
        content.addView(stat("当前回归",String.valueOf(ret)+" 项"));
        content.addView(text("数据只统计已记录的真实执行结果。",13));
    }
    LinearLayout stat(String a,String b){
        LinearLayout c=card(); TextView x=text(a,13); x.setTextColor(MUTED); c.addView(x); TextView y=text(b,25); y.setTypeface(Typeface.DEFAULT,Typeface.BOLD); c.addView(y); return c;
    }

    void mine(){
        base("我的");
        content.addView(text("学习系统",18));
        content.addView(setting("🔔","时间提醒","任务到点提醒"));
        content.addView(setting("🔴","强制回归","未完成任务第二天继续处理"));
        content.addView(setting("🔒","标准锁定","锁定后不因失败降低标准"));
        content.addView(setting("🏆","永久通关","真正达到标准后从突破主线毕业"));
    }
    LinearLayout setting(String icon,String a,String b){
        LinearLayout c=card(); c.addView(text(icon+"  "+a,16)); c.addView(text(b,13)); return c;
    }

    LinearLayout dialogBox(String heading){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(26,22,26,18);
        l.addView(title(heading)); return l;
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void schedule(JSONObject o){
        try{
            String[] hm=o.optString("time").split(":");
            String[] ds=o.optString("date").split("-");
            Calendar c=Calendar.getInstance();
            c.set(Integer.parseInt(ds[0]),Integer.parseInt(ds[1])-1,Integer.parseInt(ds[2]),
                  Integer.parseInt(hm[0]),Integer.parseInt(hm[1]),0);
            Intent i=new Intent(this,ReminderReceiver.class);
            i.putExtra("id",o.optString("id")); i.putExtra("title",o.optString("title")); i.putExtra("detail",o.optString("detail"));
            PendingIntent pi=PendingIntent.getBroadcast(this,o.optString("id").hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(c.getTimeInMillis()>System.currentTimeMillis()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
        }catch(Exception ignored){}
    }

    // Prevent accidental default nav class name dependency.
    static class NavigationBar extends LinearLayout {
        NavigationBar(Context c){super(c);}
    }

    private void showStepBuilder() {
        LinearLayout box = verticalBox();
        EditText goal = input("例如：学会 Python");
        EditText level = input("当前水平（例如：零基础）");
        EditText daily = input("每天愿意投入多少分钟？例如：20");
        box.addView(goal);
        box.addView(level);
        box.addView(daily);

        new AlertDialog.Builder(this)
                .setTitle("铺台阶")
                .setMessage("先只说你想达到什么结果，App 会按“从容易到困难”的方式生成第一版台阶。")
                .setView(box)
                .setPositiveButton("生成台阶", (d, w) -> {
                    String g = goal.getText().toString().trim();
                    String lv = level.getText().toString().trim();
                    String tm = daily.getText().toString().trim();
                    if (g.isEmpty()) {
                        toast("请先输入一个大目标");
                        return;
                    }
                    if (lv.isEmpty()) lv = "零基础";
                    if (tm.isEmpty()) tm = "20";
                    generateSteps(g, lv, tm);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void generateSteps(String goal, String level, String minutes) {
        ArrayList<String> steps = new ArrayList<>();
        String lower = goal.toLowerCase();

        if (lower.contains("python") || goal.contains("Python") || goal.contains("编程")) {
            steps.add("第1阶：认识环境——安装/打开 Python，成功运行第一行代码");
            steps.add("第2阶：变量——能写出 5 个变量并正确打印结果");
            steps.add("第3阶：条件——独立完成 3 道 if 判断小题");
            steps.add("第4阶：循环——独立完成 3 道 for/while 小题");
            steps.add("第5阶：函数——写出 3 个自己的小函数");
            steps.add("第6阶：综合——独立完成一个 20～30 分钟的小程序");
        } else if (goal.contains("英语") || lower.contains("english")) {
            steps.add("第1阶：建立基础——每天掌握 10～15 个高频词，并能回忆");
            steps.add("第2阶：短句——每天读懂并复述 5 个简单句");
            steps.add("第3阶：听力——完成 5 分钟慢速材料，抓住主要意思");
            steps.add("第4阶：输出——每天用英语说/写 5 句话");
            steps.add("第5阶：短文——独立读懂一篇短文并复述大意");
            steps.add("第6阶：综合——完成一次 15 分钟英语输入+输出");
        } else if (goal.contains("数学") || lower.contains("math")) {
            steps.add("第1阶：基础概念——整理并说清 5 个核心概念");
            steps.add("第2阶：基础题——独立完成 5 道最基础题");
            steps.add("第3阶：变式题——完成 3 道不同问法的题");
            steps.add("第4阶：综合题——完成 2 道需要多步推理的题");
            steps.add("第5阶：错题——能解释最近 5 道错题为什么错");
            steps.add("第6阶：阶段测试——在限定时间内独立完成一套小测试");
        } else {
            steps.add("第1阶：认识目标——说清楚“学会”具体意味着什么");
            steps.add("第2阶：基础动作——完成一个 10～20 分钟的最小练习");
            steps.add("第3阶：重复——连续完成 3 次同类基础练习");
            steps.add("第4阶：变式——完成 3 个稍有变化的练习");
            steps.add("第5阶：独立——不看答案完成一次完整任务");
            steps.add("第6阶：阶段测试——用一次可检查的结果证明这一阶段已经掌握");
        }

        String safeMinutes = minutes.replaceAll("[^0-9]", "");
        if (safeMinutes.isEmpty()) safeMinutes = "20";

        StringBuilder msg = new StringBuilder();
        msg.append("目标：").append(goal).append("\n");
        msg.append("当前水平：").append(levelFor(goal)).append("\n");
        msg.append("建议每日投入：").append(safeMinutes).append(" 分钟\n\n");
        msg.append("已生成 ").append(steps.size()).append(" 个台阶：\n\n");
        for (String x : steps) msg.append("□ ").append(x).append("\n");

        new AlertDialog.Builder(this)
                .setTitle("第一版台阶已生成")
                .setMessage(msg.toString())
                .setPositiveButton("保存台阶", (d, w) -> saveStepPlan(goal, steps, safeMinutes))
                .setNeutralButton("重新生成", (d, w) -> showStepBuilder())
                .setNegativeButton("先看看", null)
                .show();
    }

    private String levelFor(String goal) {
        return "用户填写的当前水平";
    }

    private void saveStepPlan(String goal, ArrayList<String> steps, String minutes) {
        try {
            org.json.JSONArray arr = new org.json.JSONArray();
            for (String step : steps) arr.put(step);
            getPreferences(MODE_PRIVATE).edit()
                    .putString("step_goal", goal)
                    .putString("step_minutes", minutes)
                    .putString("step_list", arr.toString())
                    .apply();
            toast("台阶已保存。下一步可以把第1阶加入明日计划。");
            showSteps();
        } catch (Exception e) {
            toast("保存失败，请重试");
        }
    }

    private void showSteps() {
        String goal = getPreferences(MODE_PRIVATE).getString("step_goal", "");
        String raw = getPreferences(MODE_PRIVATE).getString("step_list", "");
        if (goal.isEmpty() || raw.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("还没有学习台阶")
                    .setMessage("先输入一个大目标，例如“我要学会 Python”。")
                    .setPositiveButton("开始铺台阶", (d,w) -> showStepBuilder())
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }

        StringBuilder msg = new StringBuilder("目标：").append(goal).append("\n\n");
        try {
            org.json.JSONArray arr = new org.json.JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                msg.append("□ ").append(arr.optString(i)).append("\n");
            }
        } catch (Exception e) {
            msg.append(raw);
        }

        new AlertDialog.Builder(this)
                .setTitle("我的学习台阶")
                .setMessage(msg.toString())
                .setPositiveButton("把第1阶加入明日计划", (d,w) -> {
                    try {
                        org.json.JSONArray arr = new org.json.JSONArray(raw);
                        if (arr.length() > 0) {
                            addGeneratedStepTask(arr.optString(0));
                        }
                    } catch (Exception e) {
                        toast("读取台阶失败");
                    }
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void addGeneratedStepTask(String step) {
        java.util.ArrayList<Task> tasks = Store.getTasks(this);
        Task t = new Task();
        t.id = "step_" + System.currentTimeMillis();
        t.title = step;
        t.detail = "来自“铺台阶”学习目标";
        t.date = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                .format(new java.util.Date(System.currentTimeMillis() + 86400000L));
        t.time = "20:00";
        t.status = "PENDING";
        t.locked = false;
        t.type = "BREAKTHROUGH";
        tasks.add(t);
        Store.saveTasks(this, tasks);
        toast("第1阶已加入明日计划");
    }


    private void showAIPlanner() {
        LinearLayout box = verticalBox();
        EditText goal = input("目标，例如：6个月看懂英文新闻");
        EditText level = input("当前水平，例如：英语四级 / 零基础 / 会一点 Python");
        EditText deadline = input("目标期限，例如：6个月");
        EditText mins = input("每天可投入，例如：30分钟");
        box.addView(goal); box.addView(level); box.addView(deadline); box.addView(mins);

        new AlertDialog.Builder(this)
                .setTitle("AI 学习引擎")
                .setMessage("AI 会把目标转换成：阶段 → 台阶 → 每日动作 → 阶段测试。后续再根据你的完成/失败记录调整下一阶。")
                .setView(box)
                .setPositiveButton("生成路径", (d,w) -> {
                    String g=goal.getText().toString().trim();
                    if(g.isEmpty()){toast("请先输入目标");return;}
                    String l=level.getText().toString().trim(); if(l.isEmpty())l="未填写";
                    String dl=deadline.getText().toString().trim(); if(dl.isEmpty())dl="未填写";
                    String m=mins.getText().toString().trim(); if(m.isEmpty())m="20分钟";
                    LearningEngine.Plan p=LearningEngine.build(g,l,dl,m);
                    saveAIPlan(p);
                    showAIPlan();
                })
                .setNegativeButton("取消",null).show();
    }

    private void saveAIPlan(LearningEngine.Plan p) {
        org.json.JSONArray stages=new org.json.JSONArray();
        try {
            for(LearningEngine.Stage st:p.stages){
                org.json.JSONObject o=new org.json.JSONObject();
                o.put("name",st.name); o.put("purpose",st.purpose); o.put("standard",st.standard);
                org.json.JSONArray a=new org.json.JSONArray();
                for(String x:st.steps)a.put(x);
                o.put("steps",a);
                stages.put(o);
            }
            getPreferences(MODE_PRIVATE).edit()
                    .putString("ai_goal",p.goal)
                    .putString("ai_level",p.currentLevel)
                    .putString("ai_deadline",p.deadline)
                    .putString("ai_minutes",p.dailyMinutes)
                    .putString("ai_stages",stages.toString())
                    .putInt("ai_stage",0)
                    .putInt("ai_step",0)
                    .apply();
            toast("AI 学习路径已建立");
        }catch(Exception e){toast("保存失败");}
    }

    private void showAIPlan() {
        String goal=getPreferences(MODE_PRIVATE).getString("ai_goal","");
        String raw=getPreferences(MODE_PRIVATE).getString("ai_stages","");
        if(goal.isEmpty()||raw.isEmpty()){
            new AlertDialog.Builder(this).setTitle("还没有 AI 学习路径")
                    .setMessage("先输入一个具体的大目标。").setPositiveButton("创建", (d,w)->showAIPlanner())
                    .setNegativeButton("取消",null).show(); return;
        }
        int si=getPreferences(MODE_PRIVATE).getInt("ai_stage",0);
        int pi=getPreferences(MODE_PRIVATE).getInt("ai_step",0);
        try{
            org.json.JSONArray stages=new org.json.JSONArray(raw);
            StringBuilder b=new StringBuilder("目标：").append(goal).append("\n\n");
            for(int i=0;i<stages.length();i++){
                org.json.JSONObject st=stages.getJSONObject(i);
                b.append(i==si?"▶ ":"□ ").append(st.optString("name")).append("\n");
                b.append("  标准：").append(st.optString("standard")).append("\n");
                org.json.JSONArray steps=st.optJSONArray("steps");
                if(i==si && steps!=null && steps.length()>0){
                    b.append("  当前台阶：").append(Math.min(pi+1,steps.length())).append("/").append(steps.length()).append("\n");
                    b.append("  今日动作：").append(steps.optString(Math.min(pi,steps.length()-1))).append("\n");
                }
            }
            new AlertDialog.Builder(this).setTitle("AI 学习路径").setMessage(b.toString())
                    .setPositiveButton("完成今日动作", (d,w)->aiStepResult(true))
                    .setNegativeButton("今日失败", (d,w)->aiStepResult(false))
                    .setNeutralButton("重新规划", (d,w)->showAIPlanner()).show();
        }catch(Exception e){toast("读取路径失败");}
    }

    private void aiStepResult(boolean success){
        int si=getPreferences(MODE_PRIVATE).getInt("ai_stage",0);
        int pi=getPreferences(MODE_PRIVATE).getInt("ai_step",0);
        String raw=getPreferences(MODE_PRIVATE).getString("ai_stages","");
        try{
            org.json.JSONArray stages=new org.json.JSONArray(raw);
            org.json.JSONObject st=stages.getJSONObject(si);
            org.json.JSONArray steps=st.optJSONArray("steps");
            if(!success){
                // AI engine rule: failed -> keep the same step, add a recovery task.
                addRecoveryAIAction(steps.optString(Math.min(pi,steps.length()-1)));
                toast("AI 判定：暂不升级，先巩固当前台阶");
                return;
            }
            if(pi+1<steps.length()){
                getPreferences(MODE_PRIVATE).edit().putInt("ai_step",pi+1).apply();
                toast("通过：进入下一小台阶");
            }else if(si+1<stages.length()){
                // Stage gate: require a stage test before advancing.
                showStageGate(si);
            }else{
                toast("全部阶段完成：目标已永久通关");
                getPreferences(MODE_PRIVATE).edit().putBoolean("ai_permanent_pass",true).apply();
            }
        }catch(Exception e){toast("更新失败");}
    }

    private void showStageGate(int si){
        String raw=getPreferences(MODE_PRIVATE).getString("ai_stages","");
        try{
            org.json.JSONArray stages=new org.json.JSONArray(raw);
            org.json.JSONObject st=stages.getJSONObject(si);
            new AlertDialog.Builder(this).setTitle("阶段测试")
                    .setMessage("标准：\n"+st.optString("standard")+"\n\n达到标准才能进入下一阶段。标准锁定后不再随意修改。")
                    .setPositiveButton("通过测试", (d,w)->{
                        getPreferences(MODE_PRIVATE).edit().putInt("ai_stage",si+1).putInt("ai_step",0).apply();
                        toast("阶段永久通关，进入下一阶段");
                    })
                    .setNegativeButton("测试失败", (d,w)->{
                        addRecoveryAIAction("重新训练："+st.optString("name"));
                        toast("阶段未通过：回归训练");
                    }).show();
        }catch(Exception e){}
    }

    private void addRecoveryAIAction(String action){
        java.util.ArrayList<Task> tasks=Store.getTasks(this);
        Task t=new Task();
        t.id="ai_recovery_"+System.currentTimeMillis();
        t.title="AI回归："+action;
        t.detail="AI 学习引擎根据失败记录生成的回归任务";
        t.date=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.getDefault()).format(new java.util.Date());
        t.time="20:00"; t.status="RETURN"; t.locked=true; t.type="BREAKTHROUGH";
        tasks.add(t); Store.saveTasks(this,tasks);
    }

}
