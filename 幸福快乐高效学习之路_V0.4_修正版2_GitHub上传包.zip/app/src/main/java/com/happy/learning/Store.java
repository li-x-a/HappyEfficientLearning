package com.happy.learning;

import android.content.*;
import org.json.*;
import java.util.*;

public class Store {
    static final String PREF="learning_v02";

    static JSONArray get(Context c, String key) {
        String s=c.getSharedPreferences(PREF,0).getString(key,"[]");
        try { return new JSONArray(s); } catch(Exception e) { return new JSONArray(); }
    }
    static void put(Context c,String key,JSONArray a) {
        c.getSharedPreferences(PREF,0).edit().putString(key,a.toString()).apply();
    }
    static String id(){ return UUID.randomUUID().toString(); }
}
