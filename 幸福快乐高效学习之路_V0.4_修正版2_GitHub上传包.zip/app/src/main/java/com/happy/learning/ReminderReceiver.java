package com.happy.learning;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL = "learning_reminders";

    @Override public void onReceive(Context context, Intent intent) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL, "学习提醒", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("任务开始提醒");
            nm.createNotificationChannel(ch);
        }
        String title = intent.getStringExtra("title");
        String detail = intent.getStringExtra("detail");
        String id = intent.getStringExtra("id");
        Intent open = new Intent(context, MainActivity.class);
        open.putExtra("taskId", id);
        PendingIntent pi = PendingIntent.getActivity(
            context, id == null ? 1 : id.hashCode(), open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, CHANNEL)
            : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder)
         .setContentTitle(title == null ? "学习提醒" : "该开始学习了")
         .setContentText(detail == null ? "打开 App 开始任务" : detail)
         .setAutoCancel(true)
         .setContentIntent(pi)
         .setPriority(Notification.PRIORITY_HIGH);
        nm.notify(id == null ? 1 : id.hashCode(), b.build());
    }
}
